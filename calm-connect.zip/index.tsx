import { GoogleGenAI } from "@google/genai";

// --- STATE AND INITIALIZATION ---

const app = document.getElementById('app') as HTMLDivElement;
if (!app) throw new Error('Root element #app not found');

// Basic state management
const state = {
  isAuthenticated: false,
  currentPage: 'home', // 'home', 'guide', 'community', 'resources'
  isLoading: false,
  quote: 'Loading an inspiring thought for you...',
  chatMessages: [
    { from: 'other', text: 'Welcome to the community chat! Feel free to share your thoughts respectfully.' }
  ],
};

// Initialize Gemini API
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- API HELPERS ---

async function fetchInspirationalQuote() {
  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: "Generate a short, calming, and inspirational quote about mental well-being or overcoming challenges.",
        config: {
          temperature: 0.9
        }
    });
    state.quote = response.text;
  } catch (error) {
    console.error("Failed to fetch quote:", error);
    state.quote = "The journey of a thousand miles begins with a single step. - Lao Tzu";
  }
}

async function getGuidedAdvice(issue: string): Promise<string> {
  setLoading(true, 'guidance-content');
  try {
    const prompt = `Act as a mental health companion for Calm Connect. A user is feeling ${issue}. Provide a short, gentle, and actionable step-by-step guided exercise (3-5 steps) to help them calm down and manage this feeling. Use markdown for formatting like bolding and lists. The tone should be supportive and empathetic.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Failed to get guidance:", error);
    return "I'm having a little trouble connecting right now. Let's try a simple breathing exercise:\n1. **Inhale deeply** through your nose for 4 seconds.\n2. **Hold your breath** for 4 seconds.\n3. **Exhale slowly** through your mouth for 6 seconds.\nRepeat this a few times until you feel more centered.";
  } finally {
    setLoading(false, 'guidance-content');
  }
}

async function moderateAndAddMessage(message: string) {
  setLoading(true, 'chat-input-wrapper');
  try {
    const moderationPrompt = `You are a strict chat moderator for a mental health support app. Analyze the following user message for harmful, inappropriate, or toxic content. Respond with only 'ALLOW' if it's safe, or 'DENY' if it's not.\n\nMessage: "${message}"`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: moderationPrompt,
    });

    if (response.text.trim().toUpperCase() === 'ALLOW') {
      state.chatMessages.push({ from: 'user', text: message });
    } else {
      alert("This message was flagged as inappropriate and will not be sent. Please be kind and respectful.");
    }
    renderAppLayout(); // Re-render to show the new message or nothing
  } catch (error) {
    console.error("Moderation failed:", error);
    alert("Could not send message due to a connection error.");
  } finally {
    setLoading(false, 'chat-input-wrapper');
  }
}

async function fetchArticleContent(topic: string): Promise<string> {
    setLoading(true, 'resource-viewer');
    try {
        const prompt = `Act as a mental health writer for Calm Connect. Write a short, easy-to-read, and supportive article (about 150-200 words) on the topic of "${topic}". Use simple language and a reassuring tone.`;
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return `<p>${response.text.replace(/\n/g, '<br><br>')}</p>`;
    } catch (error) {
        console.error("Failed to fetch article:", error);
        return "<p>Sorry, we couldn't load this article right now. Please try again later.</p>";
    } finally {
        setLoading(false, 'resource-viewer');
    }
}


// --- UI RENDERING ---

function setLoading(isLoading: boolean, elementId?: string) {
  state.isLoading = isLoading;
  if(elementId) {
      const el = document.getElementById(elementId);
      if(el) {
          if (isLoading) {
              el.innerHTML = '<div class="loader">Loading...</div>';
          }
      }
  }
}

function renderHeader() {
  return `<header><h1>Calm Connect</h1></header>`;
}

function renderNav() {
  const pages = ['home', 'guide', 'community', 'resources', 'logout'];
  const icons = ['🏠', '🌿', '💬', '📚', '🚪'];
  const labels = ['Home', 'Guide', 'Community', 'Resources', 'Logout'];
  return `
    <nav>
      ${pages.map((page, index) => `
        <button id="nav-${page}" class="${state.currentPage === page ? 'active' : ''}">
          <span class="icon">${icons[index]}</span>
          ${labels[index]}
        </button>
      `).join('')}
    </nav>
  `;
}

function renderHomePage() {
  return `
    <h2 class="page-title">Welcome Back</h2>
    <div class="card quote-card">
      <p>${state.quote}</p>
    </div>
    <div class="card">
      <h3>Quick Relaxation</h3>
      <div class="resource-grid">
        <div class="resource-item" data-page="guide" data-issue="Stress">5-Min Stress Relief</div>
        <div class="resource-item" data-page="guide" data-issue="Anxiety">Anxiety Calmer</div>
        <div class="resource-item" data-page="resources" data-resource="music" data-type="music">Calming Music</div>
        <div class="resource-item" data-page="resources" data-resource="videos" data-type="video">Relaxing Videos</div>
      </div>
    </div>
  `;
}

function renderGuidePage() {
  return `
    <h2 class="page-title">Guided Help</h2>
    <div class="card">
      <h3>How are you feeling today?</h3>
      <div class="issue-selector">
        <button data-issue="Stress">Stress</button>
        <button data-issue="Anxiety">Anxiety</button>
        <button data-issue="Overwhelmed">Overwhelmed</button>
        <button data-issue="Sadness">Sadness</button>
      </div>
    </div>
    <div class="card">
      <h3>Your Personal Guide</h3>
      <div id="guidance-content">
        <p>Select a feeling above to receive a personalized guided exercise.</p>
      </div>
    </div>
  `;
}

function renderCommunityPage() {
    return `
      <h2 class="page-title">Community Space</h2>
      <div class="card">
        <h3>Share & Connect</h3>
        <p class="community-guideline">This is a monitored space for positive support. Be kind and respectful.</p>
        <div id="chat-messages">
            ${state.chatMessages.map(msg => `
                <div class="chat-message ${msg.from}">${msg.text}</div>
            `).join('')}
        </div>
        <form id="chat-form">
          <div id="chat-input-wrapper">
             <input type="text" id="chat-input" placeholder="Type your message..." required autocomplete="off">
             <button type="submit">Send</button>
          </div>
        </form>
      </div>
    `;
}

function renderResourcesPage() {
    return `
      <h2 class="page-title">Wellness Resources</h2>
      <div class="card">
        <div id="resource-viewer">
          <p>Select a resource below to view it here.</p>
        </div>
      </div>
      <div class="card">
        <h3>Articles & Guides</h3>
        <div class="resource-list">
          <div class="resource-list-item" data-type="article" data-resource="Understanding Anxiety">
            <span class="icon">📝</span>
            <p>Understanding Anxiety</p>
          </div>
           <div class="resource-list-item" data-type="article" data-resource="Simple Mindfulness Habits">
            <span class="icon">📝</span>
            <p>10 Simple Mindfulness Habits</p>
          </div>
        </div>
      </div>
      <div class="card">
        <h3>Relaxation Library</h3>
         <div class="resource-list-item" data-type="music">
            <span class="icon">🎵</span>
            <p>Calming Instrumental Music</p>
          </div>
           <div class="resource-list-item" data-type="video">
            <span class="icon">🎬</span>
            <p>Serene Nature Scenes Video</p>
          </div>
      </div>
      <div class="card">
        <h3>Find Nearby Experts (Demo)</h3>
         <div class="resource-list-item">
            <span class="icon">👩‍⚕️</span>
            <p>Dr. Ben Carter, PhD - Psychology (1.2 miles away)</p>
          </div>
           <div class="resource-list-item">
            <span class="icon">👨‍⚕️</span>
            <p>Oakwood Mental Wellness Center (2.5 miles away)</p>
          </div>
      </div>
    `;
}

function renderLoginPage() {
    // This is a base64 representation of the logo image you provided.
    const logoBase64 = `data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAJACQA DASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1VXVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9Bvjt8YdH+CHw51PxZrFxBFb2cR2ec4RZHI4UE+tcP8AEP4/wAOr/Arw/43+G+s6Trc2r6pYaYkRu45RuuJ0jIKqx3DDZx7V0n7RfwT0b46/DbUvDOtW8E8VzERH5yB/LYjgjPGa8/8Rfs++H9P+BPh7wN8NtJ0nQIdI1TStUWFbeOFfMt7hJSSyKNxwnGetAHc/ET4h6p4f+K/w28MWhtVsfEEmpLdmSMmQfZ4BKnltnAyTzkHivWq8K+JHg3VvEPxd+Gfia1t1k0/QJNTW8YyBWX7TAI02r1bJ646V7rQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRR ...`;
    return `
        <div class="login-container">
            <div class="logo">
                <img id="login-logo" src="${logoBase64}" alt="Calm Connect Logo"/>
            </div>
            <div class="card auth-card">
                <form id="auth-form">
                    <input type="email" placeholder="Email Address" required>
                    <input type="password" placeholder="Password" required>
                    <button type="submit" class="auth-button" id="login-btn">Log In</button>
                    <button type="button" class="auth-button secondary" id="register-btn">Register Account</button>
                </form>
                <a href="#" id="forgot-password" class="forgot-password-link">Forgot Password?</a>
                <div class="social-divider">
                    <span>or continue with</span>
                </div>
                <div class="social-login">
                    <button class="social-btn google">G</button>
                    <button class="social-btn facebook">f</button>
                    <button class="social-btn twitter">t</button>
                    <button class="social-btn instagram">i</button>
                </div>
            </div>
        </div>
    `;
}

// --- MAIN RENDER AND EVENT HANDLING ---

function renderAppLayout() {
  const currentPageContent = {
    home: renderHomePage,
    guide: renderGuidePage,
    community: renderCommunityPage,
    resources: renderResourcesPage,
  }[state.currentPage]();

  app.innerHTML = `
    <div id="app-shell">
      ${renderHeader()}
      <main>
        ${currentPageContent}
      </main>
      ${renderNav()}
    </div>
  `;
  addAppEventListeners();
  // Scroll chat to bottom
  if (state.currentPage === 'community') {
    const chatMessages = document.getElementById('chat-messages');
    if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
  }
}

function navigate(page: string) {
  if (page === 'logout') {
      logout();
      return;
  }
  state.currentPage = page;
  renderAppLayout();
}

function addAppEventListeners() {
  // Navigation
  document.getElementById('nav-home')?.addEventListener('click', () => navigate('home'));
  document.getElementById('nav-guide')?.addEventListener('click', () => navigate('guide'));
  document.getElementById('nav-community')?.addEventListener('click', () => navigate('community'));
  document.getElementById('nav-resources')?.addEventListener('click', () => navigate('resources'));
  document.getElementById('nav-logout')?.addEventListener('click', () => navigate('logout'));

  // Home page quick links
  document.querySelectorAll('.resource-item[data-page]').forEach(item => {
      item.addEventListener('click', () => {
          const page = (item as HTMLElement).dataset.page;
          const issue = (item as HTMLElement).dataset.issue;
          const type = (item as HTMLElement).dataset.type;
          const resource = (item as HTMLElement).dataset.resource;
          
          if(page) {
              navigate(page);
              // Wait for page to render before performing actions
              setTimeout(() => {
                if (page === 'guide' && issue) {
                    const button = document.querySelector(`.issue-selector button[data-issue="${issue}"]`) as HTMLButtonElement;
                    if(button) button.click();
                }
                if (page === 'resources' && type) {
                    const resourceItem = document.querySelector(`.resource-list-item[data-type="${type}"][data-resource="${resource}"]`) as HTMLElement || document.querySelector(`.resource-list-item[data-type="${type}"]`) as HTMLElement;
                    if(resourceItem) resourceItem.click();
                }
              }, 100);
          }
      });
  });

  // Guide page issue selection
  if (state.currentPage === 'guide') {
    document.querySelectorAll('.issue-selector button').forEach(button => {
      button.addEventListener('click', async (e) => {
        const target = e.target as HTMLButtonElement;
        const issue = target.dataset.issue;
        if (!issue) return;
        
        document.querySelectorAll('.issue-selector button').forEach(btn => btn.classList.remove('selected'));
        target.classList.add('selected');

        const guidanceContent = document.getElementById('guidance-content');
        if (guidanceContent) {
           const advice = await getGuidedAdvice(issue);
           let htmlAdvice = advice
             .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
             .replace(/^\* (.*)$/gm, '<li>$1</li>')
             .replace(/^\d+\. (.*)$/gm, '<li>$1</li>')
             .replace(/\n/g, '<br>');

           if (htmlAdvice.includes('<li>')) {
               htmlAdvice = `<ul>${htmlAdvice.replace(/<br>/g, '')}</ul>`
           }
           guidanceContent.innerHTML = htmlAdvice;
        }
      });
    });
  }
  
  // Community chat form
  if (state.currentPage === 'community') {
      const chatForm = document.getElementById('chat-form');
      const chatInput = document.getElementById('chat-input') as HTMLInputElement;
      if(chatForm && chatInput) {
          chatForm.addEventListener('submit', (e) => {
              e.preventDefault();
              const message = chatInput.value.trim();
              if(message && !state.isLoading) {
                  moderateAndAddMessage(message);
                  chatInput.value = '';
              }
          });
      }
  }

  // Resources Page
  if (state.currentPage === 'resources') {
      document.querySelectorAll('.resource-list-item').forEach(item => {
          item.addEventListener('click', async () => {
              const el = item as HTMLElement;
              const type = el.dataset.type;
              const resource = el.dataset.resource;
              const viewer = document.getElementById('resource-viewer');
              if (!viewer) return;

              document.querySelectorAll('.resource-list-item').forEach(i => i.classList.remove('selected'));
              el.classList.add('selected');

              if (type === 'article' && resource) {
                  viewer.innerHTML = await fetchArticleContent(resource);
              } else if (type === 'music') {
                  viewer.innerHTML = `
                    <h3>Calming Music</h3>
                    <div class="media-container">
                      <iframe style="border-radius:12px" src="https://open.spotify.com/embed/playlist/37i9dQZF1DWU0ScTcjAxCX?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
                    </div>
                  `;
              } else if (type === 'video') {
                  viewer.innerHTML = `
                    <h3>Relaxing Video</h3>
                    <div class="media-container">
                      <iframe width="560" height="315" src="https://www.youtube.com/embed/L1QJADbM7gQ?si=x_GkYx2Z4qLw5R_p&autoplay=1&mute=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    </div>
                  `;
              }
          });
      });
  }
}

function addAuthEventListeners() {
    document.getElementById('auth-form')?.addEventListener('submit', (e) => {
        e.preventDefault();
        login();
    });
    document.getElementById('register-btn')?.addEventListener('click', () => {
        alert("Registration Successful! Please log in.");
    });
    document.getElementById('forgot-password')?.addEventListener('click', () => {
        alert("A password reset link has been sent to your email address (simulation).");
    });
    document.querySelectorAll('.social-btn').forEach(btn => {
        btn.addEventListener('click', login);
    });
}

function login() {
    state.isAuthenticated = true;
    render();
}

function logout() {
    state.isAuthenticated = false;
    render();
}

function render() {
    if (state.isAuthenticated) {
        renderAppLayout();
    } else {
        app.innerHTML = renderLoginPage();
        addAuthEventListeners();
    }
}

// --- INITIAL LOAD ---

async function main() {
  await fetchInspirationalQuote(); // Fetch quote on initial load
  render();
}

main();